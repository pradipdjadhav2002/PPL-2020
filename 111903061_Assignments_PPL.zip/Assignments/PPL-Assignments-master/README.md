# PPL-Assignments
PPL-20 Lab Assignments 

Name - Rishabh Agarwal
MIS - 111807069
SY Computer Engineering
Division-2
